param([Int32]$vmcount = 3)# Create Azure VMs for Class
# run in Powershell window by typing .\CreateVMs.ps1 -vmcount 3


$startnumber = 1
$vmName = "VirtualMachine"
$password = "pass@word01"
$adminUsername = "Student"
$cloudSvcName = "bschachtazurevm"
$image = "AzureVMDemoImage"
$size = "Small"
$vms = @()
for($i = $startnumber; $i -le $vmcount; $i++)
{
	$vmn = $vmName + $i
	New-AzureVMConfig -Name $vmn -InstanceSize $size -ImageName $image |
	Add-AzureEndpoint -Protocol tcp -LocalPort 3389 -PublicPort 3389 -Name "RemoteDesktop" |
	Add-AzureProvisioningConfig -Windows -AdminUsername $adminUsername -Password $password |
	New-AzureVM -ServiceName $cloudSvcName
}