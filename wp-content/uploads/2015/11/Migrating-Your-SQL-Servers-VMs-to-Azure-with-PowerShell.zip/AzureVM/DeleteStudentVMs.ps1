param([Int32]$vmcount = 3)# Delete VMs On Azure for Class
# run in Powershell window by typing .\DeleteStudentVMs.ps1 -vmcount 3

$startnumber = 1
$vmName = "VirtualMachine"
$cloudSvcName = "bschachtazurevm"
$vms = @()
for($i = $startnumber; $i -le $vmcount; $i++)
{
	$vmn = $vmName + $i
	Remove-AzureVM -ServiceName $cloudSvcName -Name $vmn -DeleteVHD
}
