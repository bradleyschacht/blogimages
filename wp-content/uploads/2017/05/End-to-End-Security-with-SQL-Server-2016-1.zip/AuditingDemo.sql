USE [master]
GO

--Drop the server audit if it already exists.
IF��EXISTS (SELECT * FROM sys.server_audits WHERE name = N'ServerAudit')
BEGIN
	ALTER SERVER AUDIT [ServerAudit] WITH (STATE = OFF) 
	DROP SERVER AUDIT [ServerAudit]
END
GO

--Create and enable the server audit.
CREATE SERVER AUDIT [ServerAudit]
	/*
	Any authenticated user can read and write to the Windows Application event log.
	The Application event log requires lower permissions than the Windows Security event log and is less secure than the Windows Security event log.
	When using a file the folder should be secured using standard directory Windows Security options.
	Any user with CONTROL SERVER permissions will be able to read audit files with master.sys.fn_get_audit_file. Audit this function if you wish to know who is accessing audit logs.
	*/
	TO FILE 
	(
		FILEPATH = N'C:\\AuditLogs\'
		,MAXSIZE = 200 MB
		,MAX_ROLLOVER_FILES = 2
		,RESERVE_DISK_SPACE = OFF
	)
	WITH
	(	
		QUEUE_DELAY = 1000
		,ON_FAILURE = CONTINUE
	)
ALTER SERVER AUDIT [ServerAudit] WITH (STATE = ON)
GO

--Create and enable the server audit specification.
CREATE SERVER AUDIT SPECIFICATION [ServerAudit_ServerSpeficiation]
	FOR SERVER AUDIT [ServerAudit]
	ADD (BACKUP_RESTORE_GROUP),
	ADD (FAILED_LOGIN_GROUP),
	ADD (LOGIN_CHANGE_PASSWORD_GROUP),
	ADD (DATABASE_CHANGE_GROUP)
	WITH (STATE = ON)

--Fail a logon.
--Backup a database.
--CREATE DATABASE MyRogueDatabase
--DROP DATABASE MyRogueDatabase

USE ContosoRetailDW
GO

--Create and enable the database audit specification on ContosoRetailDW.
CREATE DATABASE AUDIT SPECIFICATION [ServerAudit_DatabaseSpecification_ContosoRetailDW]
	FOR SERVER AUDIT [ServerAudit]
	ADD (SELECT, UPDATE, DELETE ON SCHEMA::[dbo] BY [dbo]),
	/*
	Alternately, list the audit action types separately if the criteria is different.
	ADD (SELECT ON SCHEMA::[dbo] BY [dbo]),
	ADD (UPDATE ON SCHEMA::[dbo] BY [dbo]),
	ADD (DELETE ON SCHEMA::[dbo] BY [dbo]),
	*/
	ADD (SCHEMA_OBJECT_CHANGE_GROUP),
	ADD (USER_DEFINED_AUDIT_GROUP)
	WITH (STATE = ON)
	GO

--Create a view.
	CREATE VIEW vwDimProduct AS
	SELECT * FROM DimProduct
	GO

--Select some data.
	SELECT * FROM vwDimProduct

--Drop the view.
	DROP VIEW vwDimProduct

USE [master]
GO
--Read the audit file using T-SQL.
	SELECT�TOP 100
		*
	FROM sys.fn_get_audit_file('C:\\AuditLogs\ServerAudit*.sqlaudit', DEFAULT, DEFAULT)
	ORDER BY
		event_time DESC

--Look up what each action_id means.
	SELECT * FROM sys.dm_audit_actions ORDER BY action_id

--Bring the action names together with the audit log for better visibility.
	SELECT DISTINCT
		af.event_time,
		af.sequence_number,
		aa.name,
		af.server_principal_name,
		af.server_instance_name,
		af.schema_name,
		af.object_name,
		af.statement,
		af.additional_information,
		af.user_defined_information
		--,af.*
	FROM sys.fn_get_audit_file('C:\\AuditLogs\ServerAudit*.sqlaudit',�DEFAULT, DEFAULT) af
	JOIN sys.dm_audit_actions aa
		ON aa.action_id = af.action_id
	ORDER BY
		af.event_time DESC,
		sequence_number

	/*
	USER_DEFINED_AUDIT_GROUP tracks events raised by sp_audit_write which can be written into triggers and stored procedures.
	Track changes to the unit price of a product in case employees are changing values.
	Original Data: ProductKey 1, Unit Price 12.99
	*/

	/*
	--Create a trigger on the DimProduct table to write the old and new UnitPrice values to the user_defined_information in the audit log.
		GO
		CREATE TRIGGER [dbo].[DimProduct_UnitPriceChanges] ON [dbo].[DimProduct]
		AFTER UPDATE
		AS
		DECLARE
			@MessageText NVARCHAR(500),
			@OldValue MONEY = (SELECT UnitPrice FROM deleted),
			@NewValue MONEY = (SELECT UnitPrice FROM inserted)
			PRINT @OldValue
			PRINT @NewValue
		IF @NewValue < @OldValue
			BEGIN
				SET @MessageText = 'ProductKey ' + CONVERT(VARCHAR, (SELECT ProductKey FROM inserted)) + ' UnitPrice changed from ' + CONVERT(VARCHAR, @OldValue) + ' to ' + CONVERT(VARCHAR, @NewValue)
				EXEC sp_audit_write @user_defined_event_id = 27, @succeeded = 1, @user_defined_information = @MessageText
			END
		GO

	--Change the UnitPrice to a different value.
		UPDATE DimProduct
		SET UnitPrice = 1.50
		WHERE ProductKey = 1

	--Reset the data back to the original value for next demo.
		UPDATE DimProduct
		SET UnitPrice = 12.99
		WHERE ProductKey = 1

	--Drop the trigger from the DimProduct table.
		DROP TRIGGER [dbo].[DimProduct_UnitPriceChanges] 
	*/