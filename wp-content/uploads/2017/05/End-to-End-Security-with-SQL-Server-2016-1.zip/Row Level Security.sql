/*Note: None.*/
USE OilGasDemo
GO

/*Reload the security tables just in case.*/
EXEC Refresh_Security_Tables

/*RLS can be as simple as checking the user or very complex involving multiple joins and references to security groups.*/

	--Start simple. Security to only records in the table with my name on them.
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.MyRecordsPolicy'))
		DROP SECURITY POLICY rls.MyRecordsPolicy	
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_MyRecords'))
		DROP FUNCTION rls.fn_MyRecords
	GO

	--Create the function which will be used in the security policy filter.
	CREATE FUNCTION [rls].[fn_MyRecords](@USERID NVARCHAR(128)) RETURNS TABLE WITH SCHEMABINDING AS
		RETURN
		SELECT 1 AS [fn_MyRecordsResult]
		WHERE @USERID IN
			(
				SELECT USERID
				FROM dbo.SEC_USER_MAP
				WHERE USERID = USER_NAME()
			)
	GO

	--Create the security policy which references the function previously created.
	CREATE SECURITY POLICY [rls].[MyRecordsPolicy]
		ADD FILTER PREDICATE [rls].[fn_MyRecords](USERID) ON dbo.SEC_USER_MAP
	GO

	--Check the data with a couple of users.
	SELECT * FROM dbo.SEC_USER_MAP

	EXECUTE ('SELECT * FROM dbo.SEC_USER_MAP') AS USER = 'ecross'
	EXECUTE ('SELECT * FROM dbo.SEC_USER_MAP') AS USER = 'dcampos'

	--Reset since we will be using those same tables for our more complex example.
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.MyRecordsPolicy'))
		DROP SECURITY POLICY rls.MyRecordsPolicy	
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_MyRecords'))
		DROP FUNCTION rls.fn_MyRecords
	GO

/*Let's take a look at a little more complicated example. This will leverage a hierarchy for security definitions.*/

	--This is the hierarchy our more complex security model will be based on.
	SELECT * FROM [OilGasDemo].[dbo].[ASSET_HIERARCHY]
	--And the actual security mappings back to the hierarchy.
	SELECT * FROM dbo.SEC_USER_MAP

	--This is the data we are trying to limit.
	SELECT * FROM [dbo].[WELL_MASTER]

	--Cleanup if necessary
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.WellSecurityPolicy'))
		DROP SECURITY POLICY rls.WellSecurityPolicy	
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_WellSecurity'))
		DROP FUNCTION rls.fn_WellSecurity
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_WellInsertDeny'))
		DROP FUNCTION rls.fn_WellInsertDeny
	GO

	--Create the function which will be used in the security policy filter.
	CREATE FUNCTION [rls].[fn_WellSecurity](@WellID INT) RETURNS TABLE WITH SCHEMABINDING AS
		RETURN
		SELECT 1 AS [fn_WellSecurityResult]
		WHERE 
		(
          (@WellID in 
			   (select WELL_ID from dbo.WELL_MASTER where DIVISION in (select HIERARCHY_VALUE from dbo.SEC_USER_MAP 
			            where USERID = USER_NAME() and HIERARCHY_NODE = 'DIVISION'))
			   OR
			@WellID in    
			   (select WELL_ID from dbo.WELL_MASTER where REGION in (select HIERARCHY_VALUE from dbo.SEC_USER_MAP 
			            where USERID = USER_NAME() and HIERARCHY_NODE = 'REGION'))
			OR
			@WellID in    
			   (select WELL_ID from dbo.WELL_MASTER where ASSET_GROUP in (select HIERARCHY_VALUE from dbo.SEC_USER_MAP 
			            where USERID = USER_NAME() and HIERARCHY_NODE = 'ASSET_GROUP'))
			OR
			@WellID in    
			   (select WELL_ID from dbo.WELL_MASTER where ASSET_TEAM in (select HIERARCHY_VALUE from dbo.SEC_USER_MAP 
			            where USERID = USER_NAME() and HIERARCHY_NODE = 'ASSET_TEAM'))
			OR
			@WellID in    
			   (select WELL_ID from dbo.WELL_MASTER where 'ALL' in (select HIERARCHY_VALUE from dbo.SEC_USER_MAP 
			            where USERID = USER_NAME()))
			)
		)
	GO

	--Create the InsertDeny function that will be used in the security policy.
	CREATE FUNCTION [rls].[fn_WellInsertDeny]() RETURNS TABLE WITH SCHEMABINDING AS
		RETURN
		SELECT 1 AS [fn_WellInsertDenyResult] 
		WHERE
			(
				'WELLAUTH' IN (SELECT HIERARCHY_VALUE FROM dbo.SEC_USER_EXCEPTIONS WHERE USERID = USER_NAME())
			)
	GO

	--Create the security policy which references the function previously created.
	CREATE SECURITY POLICY [rls].[WellSecurityPolicy]
		ADD FILTER PREDICATE [rls].[fn_WellSecurity](WELL_ID) ON [dbo].[WELL_MASTER],
		ADD BLOCK PREDICATE  [rls].[fn_WellInsertDeny]() ON [dbo].[WELL_MASTER] AFTER INSERT,
		ADD BLOCK PREDICATE  [rls].[fn_WellSecurity]([WELL_ID]) ON [dbo].[WELL_MASTER] AFTER UPDATE,
		ADD FILTER PREDICATE [rls].[fn_WellSecurity]([WELL_ID]) on [dbo].[WELL_DAILY_PROD],
		ADD FILTER PREDICATE [rls].[fn_WellSecurity]([WELL_ID]) on [dbo].[WELL_DOWNTIME]
	GO

	--Some test queries for the FILTER PREDICATE on dbo.WELL_MASTER
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'dcampos'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='dcampos'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'hjames'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='hjames'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'rgaines'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='rgaines'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'sjohns'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='sjohns'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'imoody'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='imoody'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'omacias'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='omacias'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'ecross'
	EXECUTE ('SELECT distinct division, region, asset_group, asset_team FROM [WELL_MASTER]') AS USER ='ecross'
	GO

	-- Grant DB Writer to a few users to tests RLS DML Triggers
	ALTER ROLE [db_datawriter] ADD MEMBER [dcampos];
	ALTER ROLE [db_datawriter] ADD MEMBER [ivang];
	ALTER ROLE [db_datawriter] ADD MEMBER [kmburu];
	ALTER ROLE [db_datawriter] ADD MEMBER [rgaines];

	--Some test queries for the insert BLOCK PREDICATE on dbo.WELL_MASTER
	SELECT USERID from dbo.SEC_USER_EXCEPTIONS WHERE USERID = 'dcampos'
	EXECUTE ('insert into WELL_MASTER([WELL_ID], [WELL_NAME], [DIVISION], [REGION], [ASSET_GROUP], [ASSET_TEAM], [PROD_YEAR], [TVD]) 
          values (1001, ''WELL #1001'', ''US'', ''NORTHERN US'', ''PRB'', ''PRB OPERATED'', 2008, 5345)') AS USER ='dcampos'
	GO
	SELECT USERID from dbo.SEC_USER_EXCEPTIONS WHERE USERID = 'ivang'
	EXECUTE ('insert into WELL_MASTER([WELL_ID], [WELL_NAME], [DIVISION], [REGION], [ASSET_GROUP], [ASSET_TEAM], [PROD_YEAR], [TVD]) 
          values (1002, ''WELL #1002'', ''INTERNATIONAL'', ''KENYA'', ''KENYA'', ''KENYA'', 2008, 5345)') AS USER ='ivang'
	GO
	SELECT USERID from dbo.SEC_USER_EXCEPTIONS WHERE USERID = 'kmburu'
	EXECUTE ('insert into WELL_MASTER([WELL_ID], [WELL_NAME], [DIVISION], [REGION], [ASSET_GROUP], [ASSET_TEAM], [PROD_YEAR], [TVD]) 
          values (1003, ''WELL #1003'', ''US'', ''SOUTHERN US'', ''GULF OF MEXICO'', ''TX GULF'', 2008, 5345)') AS USER ='kmburu'
	GO

	--Some test queries for the update BLOCK PREDICATE on dbo.WELL_MASTER. Can't update record if the result causes you not to see it any longer.
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'dcampos'
	EXECUTE ('update WELL_MASTER set [DIVISION] = ''INTERNATIONAL'', [REGION] = ''KENYA'', 
                                 [ASSET_GROUP] = ''KENYA'', [ASSET_TEAM] = ''KENYA''
		  where [WELL_ID] = 1002') AS USER ='dcampos';  -- ALL Privs so will Succeed
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'rgaines'
	EXECUTE ('update WELL_MASTER set [DIVISION] = ''INTERNATIONAL'', [REGION] = ''KENYA'', 
                                 [ASSET_GROUP] = ''KENYA'', [ASSET_TEAM] = ''KENYA''
		  where [WELL_ID] = 1003') AS USER ='rgaines';  -- No Privs to Intl, so 0 rows affected (cannot update what you cannot see)
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'rgaines'
	EXECUTE ('SELECT * FROM [WELL_MASTER]') AS USER ='rgaines'
	EXECUTE ('update WELL_MASTER set [DIVISION] = ''INTERNATIONAL'', [REGION] = ''KENYA'', 
                                 [ASSET_GROUP] = ''KENYA'', [ASSET_TEAM] = ''KENYA''
		  where [WELL_ID] = 2') AS USER ='rgaines';  -- No Privs to Intl, so will Fail (cannot update a visible row to now violate your Privs)
	GO

	--Some test queries for the FILTER PREDICATE on dbo.WELL_DAILY_PROD
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'dcampos'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='dcampos'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'dcampos'
	EXECUTE ('SELECT * FROM [WELL_DAILY_PROD]') AS USER ='dcampos';
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'hjames'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='hjames'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'hjames'
	EXECUTE ('SELECT * FROM [WELL_DAILY_PROD]') AS USER ='hjames'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'rgaines'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='rgaines'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'sjohns'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='sjohns'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'imoody'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='imoody'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'sbird'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='sbird'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'ecross'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DAILY_PROD]') AS USER ='ecross' 
	GO

	--Some test queries for the FILTER PREDICATE on dbo.WELL_DOWNTIME
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'dcampos'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='dcampos'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'hjames'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='hjames'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'rgaines'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='rgaines'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'sjohns'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='sjohns' 
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'imoody'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='imoody'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'sbird'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='sbird'
	GO
	SELECT * FROM [dbo].[SEC_USER_MAP] WHERE USERID = 'ecross'
	EXECUTE ('SELECT count(distinct WELL_ID) FROM [WELL_DOWNTIME]') AS USER ='ecross'
	GO

	--Cleanup the database.
	REVERT
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.WellSecurityPolicy'))
		DROP SECURITY POLICY rls.WellSecurityPolicy	
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_WellSecurity'))
		DROP FUNCTION rls.fn_WellSecurity
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = object_id('rls.fn_WellInsertDeny'))
		DROP FUNCTION rls.fn_WellInsertDeny
	GO
	ALTER ROLE [db_datawriter] DROP MEMBER [dcampos];
	ALTER ROLE [db_datawriter] DROP MEMBER [ivang];
	ALTER ROLE [db_datawriter] DROP MEMBER [kmburu];
	ALTER ROLE [db_datawriter] DROP MEMBER [rgaines];
	DELETE FROM WELL_MASTER WHERE WELL_ID > 1000