USE ChangeDataCapture
GO
IF EXISTS (SELECT * FROM sys.tables WHERE [name] = 'LSNControl')
DROP TABLE dbo.LSNControl
GO
CREATE TABLE dbo.LSNControl
(
LastLSN binary(10),
TableName nvarchar(50)
)
GO
INSERT INTO LSNControl(LastLSN, TableName)
VALUES
	(0x00000041000001550004, 'Product'),
	(0x00000041000001550004, 'ProductModel')
GO