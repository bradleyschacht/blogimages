USE ChangeDataCapture
GO
EXEC sys.sp_cdc_generate_wrapper_function
	@capture_instance = 'Product'
	,@update_flag_list = 'ProductNumber, Color'
	/*,@column_list parameter optional*/
GO

EXEC sys.sp_cdc_generate_wrapper_function
	@capture_instance = 'ProductModel'
GO