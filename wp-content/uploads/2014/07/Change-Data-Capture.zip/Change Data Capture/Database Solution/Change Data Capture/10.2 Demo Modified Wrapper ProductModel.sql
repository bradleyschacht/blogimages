USE ChangeDataCapture
GO
DECLARE @EndDate datetime = GETDATE()
SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v2](NULL, @EndDate, 'all with mask')
SELECT @EndDate

UPDATE ControlCDC
SET LastReadDate = ''
WHERE TableName = 'ProductModel'

INSERT INTO ProductModel (ProductModelID, Name)
VALUES (-2, 'One More Model')
GO

/*Run select then update then select*/

UPDATE ProductModel
SET Name = 'Sorry, Wrong Name'
WHERE ProductModelID = -2
GO

/*Run select then update then select*/

SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v2](NULL, NULL, 'all with mask')
SELECT * FROM [dbo].[Fn_net_changes_productmodel](NULL, NULL, 'all with mask')