USE ChangeDataCapture
GO
IF EXISTS (SELECT * FROM sys.tables WHERE [name] = 'ControlCDC')
DROP TABLE dbo.ControlCDC
GO
CREATE TABLE dbo.ControlCDC
(
LastReadDate datetime,
TableName nvarchar(50)
)
GO
INSERT INTO ControlCDC(LastReadDate, TableName)
VALUES
	(NULL, 'Product'),
	(NULL, 'ProductModel')
GO