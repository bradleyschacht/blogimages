USE ChangeDataCapture
GO
BEGIN TRY
DROP FUNCTION [dbo].[Fn_net_changes_product_modified_v1]
END TRY
BEGIN CATCH
END Catch
GO

CREATE FUNCTION [Fn_net_changes_product_modified_v1] (@start_time        DATETIME = NULL, 
                                          @end_time          DATETIME = NULL, 
                                          @row_filter_option NVARCHAR(30) = N'all') 
returns @resultset TABLE ( 
  [productid]           INT, 
  [name]                NVARCHAR(50), 
  [productnumber]       NVARCHAR(25), 
  [color]               NVARCHAR(15), 
  [productmodelid]      INT, 
  [__cdc_operation]     VARCHAR(2), 
  [productnumber_uflag] BIT, 
  [color_uflag]         BIT ) 
AS 
  BEGIN 
      DECLARE @from_lsn BINARY(10), 
              @to_lsn   BINARY(10) 
      DECLARE @ordinal_1 INT 

      SELECT @ordinal_1 = [sys].[Fn_cdc_get_column_ordinal] ('Product', 'ProductNumber') 

      DECLARE @ordinal_2 INT 

      SELECT @ordinal_2 = [sys].[Fn_cdc_get_column_ordinal] ('Product', 'Color') 
/******************************************************************************************************************************/
/*Begin of Original
	  IF ( @start_time IS NULL ) 
        SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('Product')
End of Original*/
	  IF ( @start_time IS NULL ) 
		BEGIN 
			IF(SELECT LastLSN FROM dbo.LSNControl WHERE TableName = 'Product') = 0x00000000000000000000 
			SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('Product') 
			ELSE 
			SELECT top 1 @from_lsn = LastLSN FROM dbo.LSNControl WHERE TableName = 'Product'
		END 
/******************************************************************************************************************************/
      ELSE 
        BEGIN 
            IF ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_min_lsn]('Product')) > @start_time )
                OR ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @start_time )
              SELECT @from_lsn = NULL 
            ELSE 
              SELECT @from_lsn = [sys].[Fn_cdc_increment_lsn]([sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @start_time))
        END 

      IF ( @end_time IS NULL ) 
        SELECT @to_lsn = [sys].[Fn_cdc_get_max_lsn]() 
      ELSE 
        BEGIN 
            IF [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @end_time 
              SELECT @to_lsn = NULL 
            ELSE 
              SELECT @to_lsn = [sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @end_time)
        END 

      IF @from_lsn IS NOT NULL 
         AND @to_lsn IS NOT NULL 
         AND ( @from_lsn = [sys].[Fn_cdc_increment_lsn](@to_lsn) ) 
        RETURN 
/******************************************************************************************************************************/
/*Added section*/
		IF(@to_lsn > @from_lsn)
		BEGIN
		SET @from_lsn = [sys].[fn_cdc_increment_lsn](@from_lsn)
/******************************************************************************************************************************/
      INSERT INTO @resultset 
      SELECT [productid], 
             [name], 
             [productnumber], 
             [color], 
             [productmodelid], 
             CASE [__$operation] 
               WHEN 1 THEN 'D' 
               WHEN 2 THEN 'I' 
               WHEN 3 THEN 'UO' 
               WHEN 4 THEN 'UN' 
               WHEN 5 THEN 'M' 
               ELSE NULL 
             END AS [__CDC_OPERATION], 
             CASE [__$operation] 
               WHEN 4 THEN 
                 CASE ( Isnull(Cast([__$update_mask] AS VARCHAR), '') ) 
                   WHEN '' THEN NULL 
                   ELSE [sys].[Fn_cdc_is_bit_set](@ordinal_1, [__$update_mask]) 
                 END 
               ELSE NULL 
             END AS [ProductNumber_uflag], 
             CASE [__$operation] 
               WHEN 4 THEN 
                 CASE ( Isnull(Cast([__$update_mask] AS VARCHAR), '') ) 
                   WHEN '' THEN NULL 
                   ELSE [sys].[Fn_cdc_is_bit_set](@ordinal_2, [__$update_mask]) 
                 END 
               ELSE NULL 
             END AS [Color_uflag] 
      FROM   [cdc].[Fn_cdc_get_net_changes_product](@from_lsn, @to_lsn, @row_filter_option) 
/******************************************************************************************************************************/
		END
/******************************************************************************************************************************/
      RETURN 
  END