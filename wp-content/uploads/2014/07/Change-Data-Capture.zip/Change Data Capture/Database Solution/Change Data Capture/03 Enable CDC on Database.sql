USE ChangeDataCapture
GO

EXEC sys.sp_cdc_enable_db
GO

/*
EXEC sys.sp_cdc_disable_db
GO
*/