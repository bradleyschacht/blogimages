USE ChangeDataCapture
GO
SELECT * FROM [dbo].[Fn_net_changes_product](NULL, NULL, 'all with mask')

INSERT INTO Product (ProductID, Name, ProductNumber, MakeFlag, Color, DaysToManufacture, ProductModelID)
VALUES (-1, 'New Product', 'TEST-01', 1, 'Blue', 7, NULL)
GO

SELECT * FROM [dbo].[Fn_net_changes_product](NULL, NULL, 'all with mask')
SELECT * FROM cdc.Product_CT

UPDATE Product
SET Color = 'Red'
WHERE ProductID = -1
GO

SELECT * FROM [dbo].[Fn_net_changes_product](NULL, NULL, 'all with mask')
SELECT * FROM cdc.Product_CT

DECLARE
	@startLSN binary(10),
	@endLSN binary(10) 

SELECT
	@startLSN = 0x00000041000001550004, /*REPLACE FROM TABLE*/
	@endLSN = [sys].[fn_cdc_get_max_lsn]()

SELECT 
	*,
	case [__$operation]       
					when 4 
						then        
							case (isnull(cast([__$update_mask] as varchar),''))        
								when '' then null         
								else [sys].[fn_cdc_is_bit_set](12, [__$update_mask])       
							end       
					else null      
				end as [HouseOwnerFlag_uflag] 
FROM  cdc.[fn_cdc_get_net_changes_Product]  (@startLSN, @endLSN, 'all with mask')