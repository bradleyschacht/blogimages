USE ChangeDataCapture
GO
SELECT * FROM [dbo].[Fn_net_changes_productmodel](NULL, NULL, 'all with mask')

INSERT INTO ProductModel (ProductModelID, Name)
VALUES (-1, 'My Model')
GO

SELECT * FROM [dbo].[Fn_net_changes_productmodel](NULL, NULL, 'all with mask')
SELECT * FROM cdc.ProductModel_CT

UPDATE ProductModel
SET Name = 'Baseball Model'
WHERE ProductModelID = -1
GO

SELECT * FROM [dbo].[Fn_net_changes_productmodel](NULL, NULL, 'all with mask')
SELECT * FROM cdc.ProductModel_CT

DECLARE
	@startLSN binary(10),
	@endLSN binary(10) 

SELECT
	@startLSN = 0x00000024000000E80004, /*REPLACE FROM TABLE*/
	@endLSN = [sys].[fn_cdc_get_max_lsn]()

SELECT 
	*,
	case [__$operation]       
					when 4 
						then        
							case (isnull(cast([__$update_mask] as varchar),''))        
								when '' then null         
								else [sys].[fn_cdc_is_bit_set](12, [__$update_mask])       
							end       
					else null      
				end as [HouseOwnerFlag_uflag] 
FROM  cdc.[fn_cdc_get_net_changes_ProductModel]  (@startLSN, @endLSN, 'all with mask')