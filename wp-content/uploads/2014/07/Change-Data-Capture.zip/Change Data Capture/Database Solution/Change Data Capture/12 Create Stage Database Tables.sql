USE ChangeDataCaptureStage
GO

SELECT ProductID, Name, ProductNumber, Color, ProductModelID
INTO ChangeDataCaptureStage.dbo.Product
FROM ChangeDataCapture.dbo.Product

SELECT ProductModelID, Name, CatalogDescription, Instructions, rowguid, ModifiedDate
INTO ChangeDataCaptureStage.dbo.ProductModel
FROM ChangeDataCapture.dbo.ProductModel

SELECT TOP 0 *
INTO ChangeDataCaptureStage.dbo.Product_CT
FROM ChangeDataCapture.dbo.Fn_net_changes_product_modified_v2(NULL, NULL, 'all with mask')

SELECT TOP 0 *
INTO ChangeDataCaptureStage.dbo.ProductModel_CT
FROM ChangeDataCapture.dbo.Fn_net_changes_productmodel_modified_v2(NULL, NULL, 'all with mask')