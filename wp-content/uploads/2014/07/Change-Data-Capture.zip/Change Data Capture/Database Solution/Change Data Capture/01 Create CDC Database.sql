USE Master
GO
IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'ChangeDataCapture')
BEGIN
	ALTER DATABASE [ChangeDataCapture] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE [ChangeDataCapture]
END
GO
CREATE DATABASE ChangeDataCapture
GO
USE [ChangeDataCapture]
GO
sp_changedbowner 'sa'
GO