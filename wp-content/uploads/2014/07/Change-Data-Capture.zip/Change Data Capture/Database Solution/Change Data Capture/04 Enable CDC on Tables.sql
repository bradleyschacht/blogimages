USE ChangeDataCapture
GO
EXEC sys.sp_cdc_enable_table
    @source_schema = 'dbo',
    @source_name = 'Product',
    @role_name = 'cdc_Admin',
    @capture_instance = 'Product',
    @supports_net_changes = 1
	,@captured_column_list = N'ProductID, Name, ProductNumber, Color, ProductModelID'
GO

EXEC sys.sp_cdc_enable_table
    @source_schema = 'dbo',
    @source_name = 'ProductModel',
    @role_name = 'cdc_Admin',
    @capture_instance = 'ProductModel',
    @supports_net_changes = 1
	--,@captured_column_list = N'ProductModelID, Name'
GO

--Additional Parameters
/*
@index_name 
@captured_column_list (default null)
@filegroup_name (default null)
@allow_partition_switch
*/

SELECT * FROM cdc.Product_CT
SELECT * FROM cdc.ProductModel_CT

/*
EXEC sys.sp_cdc_disable_table
	@source_schema = 'dbo',
	@source_name = 'Product',
	@capture_instance = 'all'
GO

EXEC sys.sp_cdc_disable_table
	@source_schema = 'dbo',
	@source_name = 'ProductModel',
	@capture_instance = 'all'
GO

SELECT
	[retention] AS RetentionMinutes,
	[retention]/60/24 AS RetentionDays
FROM [msdb].[dbo].[cdc_jobs]
WHERE
	[database_id] = DB_ID()
	AND [job_type] = 'cleanup'

/*sp_cdc_change_job @job_type='cleanup', @retention=7200*/
*/