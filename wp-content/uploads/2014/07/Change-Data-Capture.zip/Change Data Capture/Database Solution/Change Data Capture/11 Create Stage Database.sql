USE Master
GO
IF EXISTS (SELECT * FROM sys.databases WHERE [name] = 'ChangeDataCaptureStage')
BEGIN
	ALTER DATABASE [ChangeDataCaptureStage] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE [ChangeDataCaptureStage]
END

CREATE DATABASE [ChangeDataCaptureStage]
GO