USE ChangeDataCapture
GO
SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v1](NULL, NULL, 'all with mask')

INSERT INTO ProductModel (ProductModelID, Name)
VALUES (-2, 'One More Model')
GO

SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v1](NULL, NULL, 'all with mask')

UPDATE LSNControl
SET LastLSN = [sys].[fn_cdc_get_max_lsn]()
WHERE TableName = 'ProductModel'

SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v1](NULL, NULL, 'all with mask')

UPDATE ProductModel
SET Name = 'Sorry, Wrong Name'
WHERE ProductModelID = -2
GO

SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v1](NULL, NULL, 'all with mask')

UPDATE LSNControl
SET LastLSN = [sys].[fn_cdc_get_max_lsn]()
WHERE TableName = 'ProductModel'

SELECT * FROM [dbo].[Fn_net_changes_productmodel_modified_v1](NULL, NULL, 'all with mask')
SELECT * FROM [dbo].[Fn_net_changes_productmodel](NULL, NULL, 'all with mask')