/*
This demo will show that records are being brought over from the source system.
Changes are made on the source side, the SSIS package brings over the changes
then the select queries could be used as the source in a separate process to 
load only the changes into the data warehouse.
*/
/*Make changes by inserting into both tables*/
USE ChangeDataCapture
GO
INSERT INTO Product (ProductID, Name, ProductNumber, MakeFlag, Color, DaysToManufacture)
VALUES (-3, 'Something Here', 'PROD2008', NULL, 'Not a color', 3)
, (-4, 'Brad''s Bike', 'BAS29456', -3, 'Blue', 1)
GO
INSERT INTO ProductModel (ProductModelID, Name)
VALUES (-3, 'Fake Model')
, (-4, 'A Really Cool Model')
GO

/*Run the SSIS package and see Changes*/
USE ChangeDataCaptureStage
GO
SELECT
	a.ProductID,
	a.Name AS ProductName,
	a.ProductNumber,
	a.Color,
	b.Name AS ModelName,
	CASE
		WHEN aa.__cdc_operation = 'I' THEN 'Insert'
		WHEN aa.TypeIIChangeFlag = 1 THEN 'Type 2 Update'
		ELSE 'Type 1 Update' END AS Operation
FROM Product a
	LEFT JOIN Product_CT aa ON a.ProductID = aa.productid
	LEFT JOIN ProductModel b ON a.ProductModelID = b.ProductModelID
	LEFT JOIN ProductModel_CT bb ON b.ProductModelID = bb.productmodelid
WHERE
	aa.productid IS NOT NULL
	OR bb.productmodelid IS NOT NULL
SELECT * FROM Product_CT
SELECT * FROM ProductModel_CT

/***********************************************************************************************/
/*Make changes to both tables by running updates*/
USE ChangeDataCapture
GO
UPDATE Product
SET ProductModelID = -3
WHERE ProductID = -4
UPDATE ProductModel
SET Name = 'Cool Model Name'
WHERE ProductModelID = -4

/*Run the SSIS package and see Changes*/
USE ChangeDataCaptureStage
GO
SELECT
	a.ProductID,
	a.Name AS ProductName,
	a.ProductNumber,
	a.Color,
	b.Name AS ModelName,
	CASE
		WHEN aa.__cdc_operation = 'I' THEN 'Insert'
		WHEN aa.TypeIIChangeFlag = 1 THEN 'Type 2 Update'
		ELSE 'Type 1 Update' END AS Operation
FROM Product a
	LEFT JOIN Product_CT aa ON a.ProductID = aa.productid
	LEFT JOIN ProductModel b ON a.ProductModelID = b.ProductModelID
	LEFT JOIN ProductModel_CT bb ON b.ProductModelID = bb.productmodelid
WHERE
	aa.productid IS NOT NULL
	OR bb.productmodelid IS NOT NULL
SELECT * FROM Product_CT
SELECT * FROM ProductModel_CT

/***********************************************************************************************/
/*Make changes to just the main table*/
USE ChangeDataCapture
GO
UPDATE Product
SET ProductModelID = -4
WHERE ProductID = -4

/*Run the SSIS package and see Changes*/
USE ChangeDataCaptureStage
GO
SELECT
	a.ProductID,
	a.Name AS ProductName,
	a.ProductNumber,
	a.Color,
	b.Name AS ModelName,
	CASE
		WHEN aa.__cdc_operation = 'I' THEN 'Insert'
		WHEN aa.TypeIIChangeFlag = 1 THEN 'Type 2 Update'
		ELSE 'Type 1 Update' END AS Operation
FROM Product a
	LEFT JOIN Product_CT aa ON a.ProductID = aa.productid
	LEFT JOIN ProductModel b ON a.ProductModelID = b.ProductModelID
	LEFT JOIN ProductModel_CT bb ON b.ProductModelID = bb.productmodelid
WHERE
	aa.productid IS NOT NULL
	OR bb.productmodelid IS NOT NULL
SELECT * FROM Product_CT
SELECT * FROM ProductModel_CT

/***********************************************************************************************/
/*Make changes only to a join table*/
USE ChangeDataCapture
GO
UPDATE ProductModel
SET Name = 'Awesome!'
WHERE ProductModelID = -4

/*Run the SSIS package and see Changes*/
USE ChangeDataCaptureStage
GO
SELECT
	a.ProductID,
	a.Name AS ProductName,
	a.ProductNumber,
	a.Color,
	b.Name AS ModelName,
	CASE
		WHEN aa.__cdc_operation = 'I' THEN 'Insert'
		WHEN aa.TypeIIChangeFlag = 1 THEN 'Type 2 Update'
		ELSE 'Type 1 Update' END AS Operation
FROM Product a
	LEFT JOIN Product_CT aa ON a.ProductID = aa.productid
	LEFT JOIN ProductModel b ON a.ProductModelID = b.ProductModelID
	LEFT JOIN ProductModel_CT bb ON b.ProductModelID = bb.productmodelid
WHERE
	aa.productid IS NOT NULL
	OR bb.productmodelid IS NOT NULL
SELECT * FROM Product_CT
SELECT * FROM ProductModel_CT