USE ChangeDataCapture
GO
SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

INSERT INTO Product (ProductID, Name, ProductNumber, MakeFlag, Color, DaysToManufacture)
VALUES (-2, 'Another New Product', 'ATEST-01', 0, 'Orange', 3)
GO

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

UPDATE LSNControl
SET LastLSN = [sys].[fn_cdc_get_max_lsn]()
WHERE TableName = 'Product'

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

UPDATE Product
SET Color = 'Yellow'
WHERE ProductID = -2
GO

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

UPDATE LSNControl
SET LastLSN = [sys].[fn_cdc_get_max_lsn]()
WHERE TableName = 'Product'

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

/*Update a non-tracked column*/
UPDATE Product
SET MakeFlag = 1
WHERE ProductID = -2

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

UPDATE Product
SET ProductModelID = 1
WHERE ProductID = -2

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')

UPDATE LSNControl
SET LastLSN = [sys].[fn_cdc_get_max_lsn]()
WHERE TableName = 'Product'

SELECT * FROM [dbo].[Fn_net_changes_product_modified_v1](NULL, NULL, 'all with mask')
SELECT * FROM [dbo].[Fn_net_changes_product](NULL, NULL, 'all with mask')