USE ChangeDataCapture
GO
DECLARE @EndDate datetime = GETDATE()
SELECT * FROM [dbo].[Fn_net_changes_product_modified_v2](NULL, @EndDate, 'all with mask')
SELECT @EndDate

UPDATE ControlCDC
SET LastReadDate = ''
WHERE TableName = 'Product'

INSERT INTO Product (ProductID, Name, ProductNumber, MakeFlag, Color, DaysToManufacture)
VALUES (-2, 'Another New Product', 'ATEST-01', 0, 'Orange', 3)
GO

/*Run select then update then select*/

UPDATE Product
SET Color = 'Yellow'
WHERE ProductID = -2
GO

/*Run select then update then select*/

/*Update a non-tracked column*/
UPDATE Product
SET MakeFlag = 1
WHERE ProductID = -2

/*Run select*/

UPDATE Product
SET ProductModelID = 1
WHERE ProductID = -2

/*Run select then update then select*/
SELECT * FROM [dbo].[Fn_net_changes_product](NULL, NULL, 'all with mask')