USE ChangeDataCapture
GO
BEGIN TRY
DROP FUNCTION [dbo].[Fn_net_changes_productmodel_modified_v2]
END TRY
BEGIN CATCH
END Catch
GO

CREATE FUNCTION [Fn_net_changes_productmodel_modified_v2] (@start_time        DATETIME = NULL, 
                                               @end_time          DATETIME = NULL, 
                                               @row_filter_option NVARCHAR(30) = N'all') 
returns @resultset TABLE ( 
  [productmodelid]     INT, 
  [name]               NVARCHAR(50), 
  [catalogdescription] XML, 
  [instructions]       XML, 
  [rowguid]            UNIQUEIDENTIFIER, 
  [modifieddate]       DATETIME, 
  [__cdc_operation]    VARCHAR(2)) 
AS 
  BEGIN 
      DECLARE @from_lsn BINARY(10), 
              @to_lsn   BINARY(10) 

/******************************************************************************************************************************/
/*Begin of Original
      IF ( @start_time IS NULL ) 
        SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('ProductModel')
End of Original*/
	  IF ( @start_time IS NULL ) 
		BEGIN 
			IF (SELECT LastReadDate FROM dbo.ControlCDC WHERE TableName = 'ProductModel') IS NOT NULL
			SELECT @from_lsn = [sys].[Fn_cdc_increment_lsn]([sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal',(SELECT LastReadDate FROM dbo.ControlCDC WHERE TableName = 'ProductModel')))
			ELSE
			SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('ProductModel') 
		END 
/******************************************************************************************************************************/
      ELSE 
        BEGIN 
            IF ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_min_lsn]('ProductModel')) > @start_time )
                OR ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @start_time )
              SELECT @from_lsn = NULL 
            ELSE 
              SELECT @from_lsn = [sys].[Fn_cdc_increment_lsn]([sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @start_time))
        END 

      IF ( @end_time IS NULL ) 
        SELECT @to_lsn = [sys].[Fn_cdc_get_max_lsn]() 
      ELSE 
        BEGIN
/*Begin of removed lines of code
            IF [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @end_time 
              SELECT @to_lsn = NULL 
            ELSE 
End of removed lines of code*/
              SELECT @to_lsn = [sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @end_time)
        END 

      IF @from_lsn IS NOT NULL 
         AND @to_lsn IS NOT NULL 
         AND ( @from_lsn = [sys].[Fn_cdc_increment_lsn](@to_lsn) ) 
        RETURN 

/******************************************************************************************************************************/
/*Added section*/
		IF(@to_lsn > @from_lsn)
		BEGIN
/******************************************************************************************************************************/
      INSERT INTO @resultset 
      SELECT [productmodelid], 
             [name], 
             [catalogdescription], 
             [instructions], 
             [rowguid], 
             [modifieddate], 
             CASE [__$operation] 
               WHEN 1 THEN 'D' 
               WHEN 2 THEN 'I' 
               WHEN 3 THEN 'UO' 
               WHEN 4 THEN 'UN' 
               WHEN 5 THEN 'M' 
               ELSE NULL 
             END AS [__CDC_OPERATION] 
      FROM   [cdc].[Fn_cdc_get_net_changes_productmodel](@from_lsn, @to_lsn, @row_filter_option)
/******************************************************************************************************************************/
		END
/******************************************************************************************************************************/
      RETURN 
  END 