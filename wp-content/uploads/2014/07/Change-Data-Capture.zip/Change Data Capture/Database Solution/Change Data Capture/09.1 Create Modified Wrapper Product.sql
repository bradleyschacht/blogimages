USE ChangeDataCapture
GO
BEGIN TRY
DROP FUNCTION [dbo].[Fn_net_changes_product_modified_v2]
END TRY
BEGIN CATCH
END Catch
GO

CREATE FUNCTION [Fn_net_changes_product_modified_v2] (@start_time        DATETIME = NULL, 
                                          @end_time          DATETIME = NULL, 
                                          @row_filter_option NVARCHAR(30) = N'all') 
returns @resultset TABLE ( 
  [productid]           INT, 
  [name]                NVARCHAR(50), 
  [productnumber]       NVARCHAR(25), 
  [color]               NVARCHAR(15), 
  [productmodelid]      INT, 
  [__cdc_operation]     VARCHAR(2), 
/*We can remove these two columns and add just a Type 2 Change Flag Column
  [productnumber_uflag] BIT, 
  [color_uflag]         BIT
*/
  TypeIIChangeFlag BIT  ) 
AS 
  BEGIN 
      DECLARE @from_lsn BINARY(10), 
              @to_lsn   BINARY(10) 
      DECLARE @ordinal_1 INT 

      SELECT @ordinal_1 = [sys].[Fn_cdc_get_column_ordinal] ('Product', 'ProductNumber') 

      DECLARE @ordinal_2 INT 

      SELECT @ordinal_2 = [sys].[Fn_cdc_get_column_ordinal] ('Product', 'Color') 
/******************************************************************************************************************************/
/*Begin of Original
	  IF ( @start_time IS NULL ) 
        SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('Product')
End of Original*/
	  IF ( @start_time IS NULL ) 
		BEGIN 
			IF (SELECT LastReadDate FROM dbo.ControlCDC WHERE TableName = 'Product') IS NOT NULL
			SELECT @from_lsn = [sys].[Fn_cdc_increment_lsn]([sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal',(SELECT LastReadDate FROM dbo.ControlCDC WHERE TableName = 'Product')))
			ELSE
			SELECT @from_lsn = [sys].[Fn_cdc_get_min_lsn]('Product') 
		END 
/******************************************************************************************************************************/
      ELSE 
        BEGIN 
            IF ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_min_lsn]('Product')) > @start_time )
                OR ( [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @start_time )
              SELECT @from_lsn = NULL 
            ELSE 
              SELECT @from_lsn = [sys].[Fn_cdc_increment_lsn]([sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @start_time))
        END 

	   IF ( @end_time IS NULL ) 
        SELECT @to_lsn = [sys].[Fn_cdc_get_max_lsn]() 
      ELSE 
        BEGIN 
/*Begin of removed lines of code
            IF [sys].[Fn_cdc_map_lsn_to_time]([sys].[Fn_cdc_get_max_lsn]()) < @end_time 
              SELECT @to_lsn = NULL 
            ELSE 
End of removed lines of code*/
              SELECT @to_lsn = [sys].[Fn_cdc_map_time_to_lsn]('largest less than or equal', @end_time)
        END 

      IF @from_lsn IS NOT NULL 
         AND @to_lsn IS NOT NULL 
         AND ( @from_lsn = [sys].[Fn_cdc_increment_lsn](@to_lsn) ) 
        RETURN 
/******************************************************************************************************************************/
/*Added section*/
		IF(@to_lsn > @from_lsn)
		BEGIN
/******************************************************************************************************************************/
      INSERT INTO @resultset 
      SELECT [productid], 
             [name], 
             [productnumber], 
             [color], 
             [productmodelid], 
             CASE [__$operation] 
               WHEN 1 THEN 'D' 
               WHEN 2 THEN 'I' 
               WHEN 3 THEN 'UO' 
               WHEN 4 THEN 'UN' 
               WHEN 5 THEN 'M' 
               ELSE NULL 
             END AS [__CDC_OPERATION], 
/******************************************************************************************************************************/
/*This update handles type two dimensions. We flag any column change that is a type two column
Comment this section out and create a single case statement that says if it is type two change*/             
/*This was the original code:
			 CASE [__$operation] 
               WHEN 4 THEN 
                 CASE ( Isnull(Cast([__$update_mask] AS VARCHAR), '') ) 
                   WHEN '' THEN NULL 
                   ELSE [sys].[Fn_cdc_is_bit_set](@ordinal_1, [__$update_mask]) 
                 END 
               ELSE NULL 
             END AS [ProductNumber_uflag], 
             CASE [__$operation] 
               WHEN 4 THEN 
                 CASE ( Isnull(Cast([__$update_mask] AS VARCHAR), '') ) 
                   WHEN '' THEN NULL 
                   ELSE [sys].[Fn_cdc_is_bit_set](@ordinal_2, [__$update_mask]) 
                 END 
               ELSE NULL 
             END AS [Color_uflag]
End of the original code*/
/*Begin new code*/
			 CASE
				WHEN [__$operation] = 4 THEN
					CASE
						WHEN 
							sys.fn_cdc_is_bit_set(@ordinal_1,__$update_mask) = 1 or
							sys.fn_cdc_is_bit_set(@ordinal_2,__$update_mask) = 1
						THEN 1
						ELSE 0
					END
				ELSE 0 END
/*End of new code*/
/******************************************************************************************************************************/
      FROM   [cdc].[Fn_cdc_get_net_changes_product](@from_lsn, @to_lsn, @row_filter_option) 

/******************************************************************************************************************************/
		END
/******************************************************************************************************************************/
      RETURN 
  END