USE AdventureWorks2016
GO

--Create a table for us to insert some data into.
	CREATE TABLE dbo.Demo_Always_Encrypted 
	(
	   ID INT IDENTITY(1,1) PRIMARY KEY,

	   LastName NVARCHAR(45),
	   FirstName NVARCHAR(45),
	   BirthDate DATE ENCRYPTED WITH 
		(
			ENCRYPTION_TYPE = RANDOMIZED, 
			ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', 
			COLUMN_ENCRYPTION_KEY = ColumnEncryptionKey
		),
	SSN CHAR(10) COLLATE Latin1_General_BIN2 
	  ENCRYPTED WITH 
	  (
		 ENCRYPTION_TYPE = DETERMINISTIC, 
		 ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', 
		 COLUMN_ENCRYPTION_KEY = ColumnEncryptionKey
	   ) );

--Insert some data
	INSERT INTO dbo.Demo_Always_Encrypted
	VALUES('Larsen', 'Greg', '2015-01-02', '555-55-5555')

--Insert some data
	INSERT INTO dbo.Demo_Always_Encrypted (LastName, FirstName)
	VALUES('Larsen', 'Greg')

--Create a stored procedure to insert the data.
	GO
	CREATE PROCEDURE Insert_Always_Encrypted (
	@LastName varchar(45),
	@FirstName varchar(45),
	@BirthDate date, 
	@SSN CHAR(10))
	AS 
	INSERT INTO dbo.Demo_Always_Encrypted
	(LastName, FirstName, BirthDate, SSN)
	VALUES (@LastName,@FirstName,@BirthDate,@SSN)
	GO

--Execute the stored procedure
	EXEC dbo.Insert_Always_Encrypted @LastName = 'Larsen', @FirstName = 'Greg', @BirthDate = '2015-01-02', @SSN = '555-55-5555'

--Insert 2 records through the C# Application.

--Same data, different birthdate values due to randomize option.
   SELECT * FROM Demo_Always_Encrypted

--Show me all the columns with encryption enabled.
	SELECT
		OBJECT_SCHEMA_NAME(t.object_id) AS schema_name
		,t.name AS table_name
		, c.name AS column_name 
		, c.encryption_type_desc  
	FROM sys.columns c JOIN sys.column_encryption_keys k 
	ON c.column_encryption_key_id = k.column_encryption_key_id 
	JOIN sys.tables t ON c.object_id = t.object_id;

--The underlying data is the same.
	SELECT TOP 5 * FROM sales.CustomerPII ORDER BY 1
	SELECT TOP 5 * FROM Sales.CustomerPII_Randomized ORDER BY 1

--How does a GROUP BY work?
	--DETERMINISTIC
	SELECT TOP 5
		CreditCardNumber,
		COUNT(*) AS NumberRecordWithCreditCardNumber 
	FROM Sales.CustomerPII 
	GROUP BY CreditCardNumber;

	--RANDOMIZED
	SELECT TOP 5
		CreditCardNumber,
		COUNT(*) AS NumberRecordWithCreditCardNumber 
	FROM Sales.CustomerPII_Randomized 
	GROUP BY CreditCardNumber;


--How does ORDER BY work?
	SELECT TOP 5 * FROM Sales.CustomerPII ORDER BY CreditCardNumber;
	SELECT TOP 5 * FROM Sales.CustomerPII_Randomized ORDER BY CreditCardNumber;
	SELECT TOP 5 * FROM Sales.CustomerPII_Original ORDER BY CreditCardNumber;

--Using a where clause in SSMS.
	--DETERMINISTIC
	SELECT *
	FROM Sales.CustomerPII 
	WHERE CreditCardNumber = 11111000471254
	--RANDOMIZED
	SELECT *
	FROM Sales.CustomerPII_Randomized
	WHERE CreditCardNumber = 11111000471254
	--ORIGINAL
	SELECT *
	FROM Sales.CustomerPII_Original
	WHERE CreditCardNumber = 11111000471254
	--Show the C# results for DETERMINISTIC and RANDOMIZED

--How does joining data work?
	--DETERMINISTIC to DETERMINISTIC
	SELECT *
	FROM Sales.CustomerPII a
	INNER JOIN Sales.CustomerPII b ON a.SSN = b.SSN

	--DETERMINISTIC to RANDOMIZED
	SELECT *
	FROM Sales.CustomerPII a
	INNER JOIN Sales.CustomerPII_Randomized b ON a.SSN = b.SSN

	--RANDOMIZED to RANDOMIZED
	SELECT *
	FROM Sales.CustomerPII_Randomized a
	INNER JOIN Sales.CustomerPII_Randomized b ON a.SSN = b.SSN

	--DETERMINISTIC to non-encrypted
	SELECT *
	FROM Sales.CustomerPII a
	INNER JOIN Sales.CustomerPII_Original b ON a.SSN = b.SSN
	--show in C# app too.

--How do WHERE clauses work?