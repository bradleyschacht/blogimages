/*Note: Connecting with dbo will always show unmasked data.*/
USE OilGasDemo
GO

/*Show all unmasked data in the table. Notice that we have a few fields that likely should
be masked, email address, social security number and data of birth are good candidates.*/
	SELECT * FROM [SEC_ORG_USER_BASE_HID]

/*We have a few built in functions for data masking:
1. Default
2. Email
3. Custom String
4. Random*/

/*Default will mask with all XXXX for text, 0 for numeric/binary/image and 1/1/2000 for dates.*/
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN ORG_UNIT_NAME 
	ADD MASKED WITH (FUNCTION = 'default()');
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMPLID
	ADD MASKED WITH (FUNCTION = 'default()');

	EXECUTE AS USER = 'ecross'
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	REVERT

	--Remove the masking.
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN ORG_UNIT_NAME DROP MASKED;
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMPLID DROP MASKED;


/*Email will mask with aXXXXXX.com*/
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMAIL_ADDRESS 
	ADD MASKED WITH (FUNCTION = 'email()');

	--Look at the data masked.
	EXECUTE AS USER = 'ecross'
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	REVERT
	
	--Grant ecross rights to update data, but not see data.
	ALTER ROLE [db_datawriter] ADD MEMBER [ecross];
	EXECUTE AS USER = 'ecross'
	UPDATE [SEC_ORG_USER_BASE_HID] SET EMAIL_ADDRESS = REPLACE([NAME],' ', '.') + '@msoilgasco.gov';

	--Look at the data. You can change data even without being able to see it unmasked. 
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	REVERT
	SELECT * FROM [SEC_ORG_USER_BASE_HID]

	--Reset data back to .com email addresses and remove ecross from data writer.
	REVERT
	UPDATE [SEC_ORG_USER_BASE_HID] SET EMAIL_ADDRESS = REPLACE([NAME],' ', '.') + '@msoilgasco.com';

/*Custom masking using the PARTIAL function on DOB and SSN.*/
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN DOB 
	ADD MASKED WITH (FUNCTION = 'partial(6, "XXXX", 0)');
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN SSN 
	ADD MASKED WITH (FUNCTION = 'partial(0, "XXX-XX-", 4)');

	--Look at the data masked.
	EXECUTE AS USER = 'ecross'
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	REVERT

	--Keep in mind the functions do not take into account the length of the data in the field, but will only show up to the size of the field.
	--This field is a CHAR(11) so it cuts off my text and I don't see the last 4 characters of real data.
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN SSN 
	ADD MASKED WITH (FUNCTION = 'partial(0, "I can put anything here", 4)');

	--Look at the data masked.
	EXECUTE AS USER = 'ecross'
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	REVERT

/*Random only works for numeric values.*/
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMPLID 
	ADD MASKED WITH (FUNCTION = 'random(1,100)');

	--Look at the data masked.
	EXECUTE AS USER = 'ecross'
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	
	--I can still run a where clause on a masked field even without unmask permissions.
	SELECT * FROM [SEC_ORG_USER_BASE_HID] WHERE EMPLID = 1001

	--Create a temp table with a user that see the masked version of the data.
	SELECT * INTO #TempTable FROM [SEC_ORG_USER_BASE_HID]
	
	--Look at the data in the temp table.
	SELECT * FROM #TempTable
	
	--Grant UNMASK to a user or group.
	--GRANT UNMASK TO UnmaskData
	SELECT * FROM [SEC_ORG_USER_BASE_HID]
	--REVOKE UNMASK TO UnmaskData

/*Query to show all the masked columns in a database.*/
	REVERT
	SELECT c.name, tbl.name as table_name, c.is_masked, c.masking_function  
	FROM sys.masked_columns AS c  
	JOIN sys.tables AS tbl   
    		ON c.[object_id] = tbl.[object_id]  
	WHERE is_masked = 1; 

/*Reset all the data.*/
	REVERT
	DROP TABLE #TempTable
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMAIL_ADDRESS DROP MASKED;
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN DOB DROP MASKED;
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN SSN DROP MASKED;
	ALTER TABLE [SEC_ORG_USER_BASE_HID] ALTER COLUMN EMPLID DROP MASKED;
	ALTER ROLE [db_datawriter] DROP MEMBER [ecross];