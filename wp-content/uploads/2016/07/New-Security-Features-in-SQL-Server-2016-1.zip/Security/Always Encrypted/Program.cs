﻿using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

// Demo of using Always Encrypted Columns
class AlwaysEncryptedDemo
{
    SqlConnection conn;
    public AlwaysEncryptedDemo()
    {
        // Instantiate the connection
        conn = new SqlConnection(
          "data source=BS-SRV-SQL01;initial catalog=AdventureWorks2016;integrated security = False; Column Encryption Setting = Enabled; User ID = sa; Password = password1@; ");
    }

    // call methods that demo Always Encrypted
    static void Main()
    {
        AlwaysEncryptedDemo scd = new AlwaysEncryptedDemo();
        //scd.Insertdata();
        //scd.Selectdata();

        //scd.ccselectdeterministic();
        //scd.ccselectrandom();
        //scd.ccselectrange();
        scd.ccselectlast();
    }

    public void Insertdata()
    {
        try
        {
            // Open the connection for Insertion 
            conn.Open();

            // Constructed command to execute stored proceudre
            string insertString = @"dbo.Insert_Always_Encrypted";

            // Declare variable tho hold insdert command
            SqlCommand icmd = new SqlCommand(insertString, conn);

            //set command type to stored procedure
            icmd.CommandType = CommandType.StoredProcedure;

            // Set value of LastName
            SqlParameter paramLastName = icmd.CreateParameter();
            paramLastName.ParameterName = @"@LastName";
            paramLastName.DbType = DbType.AnsiStringFixedLength; ;
            paramLastName.Direction = ParameterDirection.Input;
            paramLastName.Value = "Larsen";
            icmd.Parameters.Add(paramLastName);

            // Set value of LastName
            SqlParameter paramFirstName = icmd.CreateParameter();
            paramFirstName.ParameterName = @"@FirstName";
            paramFirstName.DbType = DbType.AnsiStringFixedLength; ;
            paramFirstName.Direction = ParameterDirection.Input;
            paramFirstName.Value = "Greg";
            icmd.Parameters.Add(paramFirstName);

            // Set value of Birth Date
            SqlParameter
            paramBirthdate = icmd.CreateParameter();
            paramBirthdate.ParameterName = @"@BirthDate";
            paramBirthdate.SqlDbType = SqlDbType.Date;
            paramBirthdate.Direction = ParameterDirection.Input;
            paramBirthdate.Value = "2015-01-02";
            icmd.Parameters.Add(paramBirthdate);

            // Set value of SSN
            SqlParameter
            paramSSN = icmd.CreateParameter();
            paramSSN.ParameterName = @"@SSN";
            paramSSN.DbType = DbType.AnsiStringFixedLength;
            paramSSN.Direction = ParameterDirection.Input;
            paramSSN.Value = "555-55-5555";
            paramSSN.Size = 10;
            icmd.Parameters.Add(paramSSN);

            // Exexute Insert 
            icmd.ExecuteNonQuery();
            MessageBox.Show("Inserted Demo Record With BirthDate=" + paramBirthdate.Value + "SSN=" + paramSSN.Value);

        }
        finally
        {
            // Close the connection
            if (conn != null)
            {
                conn.Close();
            }
        }
    }
    public void Selectdata()
    {
        try
        {
            // Open the connection for Selection 
            conn.Open();

            // Read Encrypted data 
            string selectString = @"SELECT ID, LastName, FirstName, BirthDate, SSN FROM [dbo].[Demo_Always_Encrypted] ";
            SqlCommand scmd = new SqlCommand(selectString, conn);
            SqlDataReader dataRead = scmd.ExecuteReader();
            while (dataRead.Read())
            {
                MessageBox.Show("Selected Data with ID=" + dataRead["ID"].ToString() +
                                " LastName=" + dataRead["LastName"] +
                                " FirstName=" + dataRead["FirstName"] +
                                " BirthDate =" + dataRead["BirthDate"].ToString() +
                                " SSN=" + dataRead["SSN"].ToString());
            }
        }
        finally
        {
            // Close the connection
            if (conn != null)
            {
                conn.Close();
            }
        }
    }

    public void ccselectdeterministic()
    {
        conn.Open();
        // issue select statement 
        SqlCommand cmd = new SqlCommand("SELECT CustomerID, CreditCardNumber FROM Sales.CustomerPII WHERE CreditCardNumber = @CCN", conn);
        SqlParameter CCN = new SqlParameter("@CCN", System.Data.SqlDbType.NVarChar, 25);
        CCN.Value = "11111000471254";
        cmd.Parameters.Add(CCN);
        SqlDataReader reader = cmd.ExecuteReader();

        string CustomerID = "";

        // iterate through read buffer
        while (reader.Read())
        {
            //get CustomerID read
            CustomerID = reader["CustomerId"].ToString();
            //display CustomerID read
            MessageBox.Show("CustomerId = " + CustomerID);
        }

    }

    public void ccselectrandom()
    {
        conn.Open();
        // issue select statement 
        SqlCommand cmd = new SqlCommand("SELECT CustomerID, CreditCardNumber FROM Sales.CustomerPII_Randomized WHERE CreditCardNumber = @CCN", conn);
        SqlParameter CCN = new SqlParameter("@CCN", System.Data.SqlDbType.NVarChar, 25);
        CCN.Value = "11111000471254";
        cmd.Parameters.Add(CCN);
        SqlDataReader reader = cmd.ExecuteReader();

        string CustomerID = "";

        // iterate through read buffer
        while (reader.Read())
        {
            //get CustomerID read
            CustomerID = reader["CustomerId"].ToString();
            //display CustomerID read
            MessageBox.Show("CustomerId = " + CustomerID);
        }

    }

    public void ccselectrange()
    {
        conn.Open();
        // issue select statement 
        SqlCommand cmd = new SqlCommand("SELECT CustomerID, CreditCardNumber FROM Sales.CustomerPII WHERE CustomerID < @CCN", conn);
        SqlParameter CCN = new SqlParameter("@CCN", System.Data.SqlDbType.NVarChar, 25);
        CCN.Value = "17066";
        cmd.Parameters.Add(CCN);
        SqlDataReader reader = cmd.ExecuteReader();

        string CustomerID = "";

        // iterate through read buffer
        while (reader.Read())
        {
            //get CustomerID read
            CustomerID = reader["CustomerId"].ToString();
            //display CustomerID read
            MessageBox.Show("CustomerId = " + CustomerID);
        }

    }

    public void ccselectlast()
    {
        conn.Open();
        // issue select statement 
        SqlCommand cmd = new SqlCommand("SELECT a.CustomerID FROM Sales.CustomerPII a INNER JOIN Sales.CustomerPII_Original b ON a.SSN = b.SSN", conn);
        SqlParameter CCN = new SqlParameter("@CCN", System.Data.SqlDbType.NVarChar, 25);
        CCN.Value = "17066";
        cmd.Parameters.Add(CCN);
        SqlDataReader reader = cmd.ExecuteReader();

        string CustomerID = "";

        // iterate through read buffer
        while (reader.Read())
        {
            //get CustomerID read
            CustomerID = reader["CustomerId"].ToString();
            //display CustomerID read
            MessageBox.Show("CustomerId = " + CustomerID);
        }

    }
}